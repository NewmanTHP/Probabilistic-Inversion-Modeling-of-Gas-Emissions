This package was developed to perform probabilistic inversion of gas emissions.
See: https://github.com/NewmanTHP/Probabilistic-Inversion-Modeling-of-Gas-Emissions.